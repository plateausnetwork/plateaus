<!--
order: 1
-->

# Transactions

Learn more about transactions on Evmos {synopsis}

::: tip
🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧

This documentation page is currently under work in progress.

🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧 🚧
:::

<!-- 
TODO: explain what transactions are on Evmos and blockchains. 
Explain that transactions can be identified by hashes and that they can 
contain multiple messages. Why can transactions fail? 

Explain that transactions can interoperate with other blockchains.
-->

## Transaction Confirmations

<!-- TODO: why are Ethereum transactions different than Cosmos -->

## Transaction Types

<!-- TODO: explain which transactions types does Evmos support (i.e modules and changes) and provide a few examples. -->

<!-- TODO: why are Ethereum transactions different than Cosmos -->

### Cosmos Transactions

### Ethereum Transactions

<!-- TODO: transactions that interact with the EVM -->

### Interchain Transactions

<!-- TODO: transactions that use IBC or bridges to send them to other chains -->

## Transaction Receipts

<!-- TODO: explain Ethereum transaction receipts -->
