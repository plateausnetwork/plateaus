#!/usr/bin/env bash

# Modules
rm -rf modules
