<!--
order: 3
-->

# Truffle: Deploying a Smart Contract

Learn how to deploy a simple Solidity-based smart contract to Evmos using the Truffle environment {synopsis}

[Truffle](https://www.trufflesuite.com/truffle) is a development framework for deploying and managing [Solidity](https://github.com/ethereum/solidity) smart contracts.

## Install Dependencies

First, install the latest Truffle version on your machine globally.

```bash
yarn install truffle -g
```

## Create Truffle Project

In this step we will create a simple counter contract. Feel free to skip this step if you already have your own compiled contract.

Create a new directory to host the contracts and initialize it:

```console
mkdir evmos-truffle
cd evmos-truffle
```

Initialize the Truffle suite with:

```bash
truffle init
```

Create `contracts/Counter.sol` containing the following contract:

```javascript
pragma solidity >=0.7.0 <0.9.0;

contract Counter {
  uint256 counter = 0;

  function add() public {
    counter++;
  }

  function subtract() public {
    counter--;
  }

  function getCounter() public view returns (uint256) {
    return counter;
  }
}
```

Compile the contract using the `compile` command:

```bash
truffle compile
```

Create `test/counter_test.js` containing the following tests in Javascript using [Mocha](https://mochajs.org/):

```javascript
const Counter = artifacts.require("Counter")

contract('Counter', accounts => {
  const from = accounts[0]
  let counter

  before(async() => {
    counter = await Counter.new()
  })

  it('should add', async() => {
    await counter.add()
    let count = await counter.getCounter()
    assert(count == 1, `count was ${count}`)
  })
})
```

## Truffle configuration

Open `truffle-config.js` and uncomment the `development` section in `networks`:

```javascript
    development: {
      host: "127.0.0.1",     // Localhost (default: none)
      port: 8545,            // Standard Ethereum port (default: none)
      network_id: "*",       // Any network (default: none)
    },
```

This will allow your contract to connect to your Evmos local node.

## Deploy contract

In the Truffle terminal, migrate the contract using:

```bash
truffle migrate --network development
```

You should see incoming deployment logs in the Evmos daemon Terminal tab for each transaction (one to deploy `Migrations.sol` and the other to deploy `Counter.sol`).

```bash
$ I[2020-07-15|17:35:59.934] Added good transaction                       module=mempool tx=22245B935689918D332F58E82690F02073F0453D54D5944B6D64AAF1F21974E2 res="&{CheckTx:log:\"[]\" gas_wanted:6721975 }" height=3 total=1
I[2020-07-15|17:36:02.065] Executed block                               module=state height=4 validTxs=1 invalidTxs=0
I[2020-07-15|17:36:02.068] Committed state                              module=state height=4 txs=1 appHash=76BA85365F10A59FE24ADCA87544191C2D72B9FB5630466C5B71E878F9C0A111
I[2020-07-15|17:36:02.981] Added good transaction                       module=mempool tx=84516B4588CBB21E6D562A6A295F1F8876076A0CFF2EF1B0EC670AD8D8BB5425 res="&{CheckTx:log:\"[]\" gas_wanted:6721975 }" height=4 total=1
```

## Run Truffle tests

Now, you can run the Truffle tests using the Evmos node using the `test` command:

```bash
$ truffle test --network development

Using network 'development'.


Compiling your contracts...
===========================
> Everything is up to date, there is nothing to compile.



  Contract: Counter
    ✓ should add (5036ms)


  1 passing (10s)
```
