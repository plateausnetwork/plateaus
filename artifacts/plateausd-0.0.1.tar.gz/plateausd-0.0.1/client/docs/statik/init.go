package statik

// unnamed import of statik for swagger UI support
// override ethermint statik by importing it
// nolint
import _ "github.com/evmos/ethermint/client/docs/statik"

// This just for fixing the error in importing empty github.com/evmos/ethermint/client/docs/statik
